using Microsoft.VisualStudio.TestTools.UnitTesting;
using Zad2Kserokopiarka;
using System;
using System.IO;
using ver1;

namespace Zadanie2UnitTests
{
    public class ConsoleRedirectionToStringWriter : IDisposable
    {
        private StringWriter stringWriter;
        private TextWriter originalOutput;

        public ConsoleRedirectionToStringWriter()
        {
            stringWriter = new StringWriter();
            originalOutput = Console.Out;
            Console.SetOut(stringWriter);
        }

        public string GetOutput()
        {
            return stringWriter.ToString();
        }

        public void Dispose()
        {
            Console.SetOut(originalOutput);
            stringWriter.Dispose();
        }
    }


    [TestClass]
    public class UnitTestMultifunctionalDevice
    {
        [TestMethod]
        public void MultifunctionalDevice_GetState_StateOff()
        {
            MultifunctionalDevice multifunctionalDevice = new MultifunctionalDevice();
            multifunctionalDevice.PowerOff();

            Assert.AreEqual(IDevice.State.off, multifunctionalDevice.GetState());
        }

        [TestMethod]
        public void MultifunctionalDevice_GetState_StateOn()
        {
            MultifunctionalDevice multifunctionalDevice = new MultifunctionalDevice();
            multifunctionalDevice.PowerOn();

            Assert.AreEqual(IDevice.State.on, multifunctionalDevice.GetState());
        }

        [TestMethod]
        public void MultifunctionalDevice_Print_DeviceOn()
        {
            // Arrange
            var multifunctionalDevice = new MultifunctionalDevice();
            multifunctionalDevice.PowerOn();

            var currentConsoleOut = Console.Out;
            currentConsoleOut.Flush();

            // Act
            using (var consoleOutput = new ConsoleRedirectionToStringWriter())
            {
                IDocument doc1 = new PDFDocument("aaa.pdf");
                multifunctionalDevice.Print(doc1);
            }

            // Assert
            Assert.AreEqual(currentConsoleOut, Console.Out);
        }

       


        [TestMethod]
        public void MultifunctionalDevice_Scan_DeviceOn()
        {
            // Arrange
            var multifunctionalDevice = new MultifunctionalDevice();
            multifunctionalDevice.PowerOn();

            var currentConsoleOut = Console.Out;
            currentConsoleOut.Flush();

            // Act
            using (var consoleOutput = new ConsoleRedirectionToStringWriter())
            {
                IDocument doc1 = new TextDocument("kkk.text");

                multifunctionalDevice.Scan(doc1);
                Assert.IsTrue(consoleOutput.GetOutput().Contains("Scan"));
            }

            // Assert
            Assert.AreEqual(currentConsoleOut, Console.Out);
        }

        [TestMethod]
        public void MultifunctionalDevice_Scan_FormatTypeDocument()
        {
            // Arrange
            var multifunctionalDevice = new MultifunctionalDevice();
            multifunctionalDevice.PowerOn();

            var currentConsoleOut = Console.Out;
            currentConsoleOut.Flush();

            // Act
            using (var consoleOutput = new ConsoleRedirectionToStringWriter())
            {
                IDocument doc1 = new TextDocument("jjj.text");

                multifunctionalDevice.Scan(doc1, formatType: IDocument.FormatType.JPG);
                Assert.IsTrue(consoleOutput.GetOutput().Contains("Scan"));
                Assert.IsTrue(consoleOutput.GetOutput().Contains(".jpg"));

                multifunctionalDevice.Scan(doc1, formatType: IDocument.FormatType.TXT);
                Assert.IsTrue(consoleOutput.GetOutput().Contains("Scan"));
                Assert.IsTrue(consoleOutput.GetOutput().Contains(".txt"));

                multifunctionalDevice.Scan(doc1, formatType: IDocument.FormatType.PDF);
                Assert.IsTrue(consoleOutput.GetOutput().Contains("Scan"));
                Assert.IsTrue(consoleOutput.GetOutput().Contains(".pdf"));
            }

            // Assert
            Assert.AreEqual(currentConsoleOut, Console.Out);
        }

        [TestMethod]
        public void MultifunctionalDevice_ScanAndPrint_DeviceOn()
        {
            // Arrange
            var multifunctionalDevice = new MultifunctionalDevice();
            multifunctionalDevice.PowerOn();

            IDocument docFax = new PDFDocument("faaax.pdf");

            var currentConsoleOut = Console.Out;
            currentConsoleOut.Flush();

            // Act
            using (var consoleOutput = new ConsoleRedirectionToStringWriter())
            {
                multifunctionalDevice.Fax(docFax);

                // Assert
                var consoleOutputString = consoleOutput.ToString();
                Assert.IsNotNull(consoleOutputString);
            }

            // Assert
            Assert.AreEqual(currentConsoleOut, Console.Out);
        }

        

        [TestMethod]
        public void MultifunctionalDevice_PrintCounter()
        {
            MultifunctionalDevice multifunctionalDevice = new MultifunctionalDevice();
            multifunctionalDevice.PowerOn();

            IDocument doc1 = new PDFDocument("aaa.pdf");
            multifunctionalDevice.Print(doc1);
            IDocument doc2 = new TextDocument("aaa.txt");
            multifunctionalDevice.Print(doc2);
            IDocument doc3 = new ImageDocument("aaa.jpg");
            multifunctionalDevice.Print(doc3);

            multifunctionalDevice.PowerOff();
            multifunctionalDevice.PowerOn();

            Assert.AreEqual(3, multifunctionalDevice.PrintCounter);
        }

        [TestMethod]
        public void MultifunctionalDevice_ScanCounter()
        {
            var multifunctionalDevice = new MultifunctionalDevice();
            multifunctionalDevice.PowerOn();

            IDocument doc1 = new TextDocument("kkk.text");
            multifunctionalDevice.Scan(doc1);
            IDocument doc2 = new TextDocument("kkk.text"); 
            multifunctionalDevice.Scan(doc2);

            multifunctionalDevice.PowerOff();
            multifunctionalDevice.PowerOn();

            Assert.AreEqual(2, multifunctionalDevice.ScanCounter);
        }

        [TestMethod]
        public void MultifunctionalDevice_SendCounter()
        {
            MultifunctionalDevice multifunctionalDevice = new MultifunctionalDevice();
            multifunctionalDevice.PowerOn();
            multifunctionalDevice.PowerOff();
            multifunctionalDevice.PowerOn();

            IDocument docFax1 = new PDFDocument("fax.pdf");
            IDocument docFax2 = new PDFDocument("fax.pdf");

            multifunctionalDevice.Fax(docFax1);
            multifunctionalDevice.PowerOff();
            multifunctionalDevice.PowerOn();
            multifunctionalDevice.Fax(docFax2);

            Assert.AreEqual(2, multifunctionalDevice.FaxCounter);
        }

        [TestMethod]
        public void MultifunctionalDevice_PowerOnCounter()
        {
            var multifunctionalDevice = new MultifunctionalDevice();
            multifunctionalDevice.PowerOn();
            multifunctionalDevice.PowerOn();
            multifunctionalDevice.PowerOn();

            multifunctionalDevice.PowerOff();
            multifunctionalDevice.PowerOff();
            multifunctionalDevice.PowerOff();
            multifunctionalDevice.PowerOn();

            multifunctionalDevice.PowerOff();           
            multifunctionalDevice.PowerOn();

            Assert.AreEqual(5, multifunctionalDevice.Counter);
        }

    }
}

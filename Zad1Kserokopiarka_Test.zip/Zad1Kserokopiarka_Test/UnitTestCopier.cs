using Microsoft.VisualStudio.TestTools.UnitTesting;
using ver1;
using System;
using System.IO;
using Zad1Kserokopiarka;

namespace ver1UnitTests
{

    public class ConsoleRedirectionToStringWriter : IDisposable
    {
        private StringWriter stringWriter;
        private TextWriter originalOutput;

        public ConsoleRedirectionToStringWriter()
        {
            stringWriter = new StringWriter();
            originalOutput = Console.Out;
            Console.SetOut(stringWriter);
        }

        public string GetOutput()
        {
            return stringWriter.ToString();
        }

        public void Dispose()
        {
            Console.SetOut(originalOutput);
            stringWriter.Dispose();
        }
    }


    [TestClass]
    public class UnitTestCopier
    {
        [TestMethod]
        public void Copier_GetState_StateOff()
        {
            var copier = new Copier();
            copier.PowerOff();

            Assert.AreEqual(IDevice.State.off, copier.GetState()); 
        }

        [TestMethod]
        public void Copier_GetState_StateOn()
        {
            var copier = new Copier();
            copier.PowerOn();

            Assert.AreEqual(IDevice.State.on, copier.GetState());
        }


       
        [TestMethod]
        public void Copier_Print_DeviceOn()
        {
            
            var copier = new Copier();
            copier.PowerOn();

            var currentConsoleOut = Console.Out;
            currentConsoleOut.Flush();

            
            using (var consoleOutput = new ConsoleRedirectionToStringWriter())
            {
                IDocument doc1 = new PDFDocument("aaa.pdf");
                copier.Print(doc1);
            }

            
            Assert.AreEqual(currentConsoleOut, Console.Out);
        }

       
        [TestMethod]
        public void Copier_Scan_DeviceOn()
        {
            
            var copier = new Copier();
            copier.PowerOn();

            var currentConsoleOut = Console.Out;
            currentConsoleOut.Flush();

            
            using (var consoleOutput = new ConsoleRedirectionToStringWriter())
            {
                IDocument doc1 = new TextDocument("ggg.text");
                copier.Scan(doc1);
                var output = consoleOutput.GetOutput();

            }

            
            Assert.AreEqual(currentConsoleOut, Console.Out);
        }

        
        [TestMethod]
        public void Copier_Scan_FormatTypeDocument()
        {
            var copier = new Copier();
            copier.PowerOn();

            var currentConsoleOut = Console.Out;
            currentConsoleOut.Flush();
            using (var consoleOutput = new ConsoleRedirectionToStringWriter())
            {
                IDocument doc1 = new TextDocument("ggg.text");
                copier.Scan(doc1, formatType: IDocument.FormatType.JPG);
                Assert.IsTrue(consoleOutput.GetOutput().Contains("Scan"));
                Assert.IsTrue(consoleOutput.GetOutput().Contains(".jpg"));

                copier.Scan(doc1, formatType: IDocument.FormatType.TXT);
                Assert.IsTrue(consoleOutput.GetOutput().Contains("Scan"));
                Assert.IsTrue(consoleOutput.GetOutput().Contains(".txt"));

                copier.Scan(doc1, formatType: IDocument.FormatType.PDF);
                Assert.IsTrue(consoleOutput.GetOutput().Contains("Scan"));
                Assert.IsTrue(consoleOutput.GetOutput().Contains(".pdf"));
            }
            Assert.AreEqual(currentConsoleOut, Console.Out);
        }


  
        [TestMethod]
        public void Copier_ScanAndPrint_DeviceOn()
        {
            var copier = new Copier();
            copier.PowerOn();
            IDocument document = new TextDocument("kkkk.text");

            var currentConsoleOut = Console.Out;
            currentConsoleOut.Flush();
            using (var consoleOutput = new ConsoleRedirectionToStringWriter())
            {
                copier.ScanAndPrint(document);
            }
            Assert.AreEqual(currentConsoleOut, Console.Out);
        }

        

        [TestMethod]
        public void Copier_PrintCounter()
        {
            var copier = new Copier();
            copier.PowerOn();

            IDocument doc1 = new PDFDocument("aaa.pdf");
            copier.Print( doc1);
            IDocument doc2 = new TextDocument("aaa.txt");
            copier.Print(doc2);
            IDocument doc3 = new ImageDocument("aaa.jpg");
            copier.Print(doc3);

            copier.PowerOff();
            copier.PowerOn();

            copier.ScanAndPrint(doc3);
            copier.ScanAndPrint(doc1);

            Assert.AreEqual(5, copier.PrintCounter);
        }

        [TestMethod]
        public void Copier_ScanCounter()
        {
            var copier = new Copier();
            copier.PowerOn();

            IDocument doc1 = new TextDocument("kkkk.text");
            copier.Scan( doc1);
            IDocument doc2 = new TextDocument("jjj.text");
            copier.Scan(doc2);

            IDocument doc3 = new ImageDocument("aaa.jpg");
            copier.Print(doc3);

            copier.PowerOff();
            copier.PowerOn();

            copier.ScanAndPrint(doc3);
            copier.ScanAndPrint(doc3);

            Assert.AreEqual(4, copier.ScanCounter);
        }

        [TestMethod]
        public void Copier_PowerOnCounter()
        {
            var copier = new Copier();
            copier.ON();
            copier.ON();
            copier.ON();

            copier.OFF();
            copier.OFF();
            copier.OFF();
            copier.ON();

            copier.OFF();  
            copier.ON();
            
            Assert.AreEqual(5, copier.Counter);
        }

    }
}

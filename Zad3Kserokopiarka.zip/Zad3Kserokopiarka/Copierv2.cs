﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace Zad3Kserokopiarka
{
    public class Copierv2 : BaseDevice, IPrinter, IScanner
    {   
        private readonly Printer printer;
        private readonly Scanner scanner;
        private IDocument? document;


        public Copierv2()
        {
            printer = new Printer();
            scanner = new Scanner();
        }



        public int PrintCounter
        {
            get
            {
                return printer.Counter;
            }
        }

        public int ScanCounter
        {
            get
            {
                return scanner.Counter;
            }
        }

        

        public override void PowerOff()
        {   
            if (GetState() == IDevice.State.off)
            {
                return;
            }

            state = IDevice.State.off;
            printer.state = IDevice.State.off;
            scanner.state = IDevice.State.off;

            Console.WriteLine("Devices are shutting down");

        }

        public override void PowerOn()
        {
            if (GetState() == IDevice.State.on)
            {
                return;
            }

            var state3 = printer.GetState() == IDevice.State.on;

            var state4 = scanner.GetState() == IDevice.State.on;

            Console.WriteLine("Devices are turning on");
            Counter++;
        }

        public void Print(in IDocument document)
        {
            printer.Print(document);
        }

        public void Scan(out IDocument document, IDocument.FormatType formatType = IDocument.FormatType.JPG)
        {
            scanner.Scan(out document,IDocument.FormatType.JPG);
        }

        public void ScanPrint()
        {
            if (state == IDevice.State.off)
            {
                return;
            }

            Scan(out document, IDocument.FormatType.JPG);
            Print(document);


        }
    }
}

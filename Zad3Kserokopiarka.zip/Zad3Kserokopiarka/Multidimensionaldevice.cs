﻿using System;
using System.Collections.Generic;
using System.Diagnostics.Metrics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Zad3Kserokopiarka
{
    public class Multidimensionaldevice:BaseDevice,IPrinter,IScanner,IFAX
    {

        private readonly Printer printer;
        private readonly Scanner scanner;
        private readonly Fax fax;
        private IDocument? document;


        public Multidimensionaldevice()
        {
            printer = new Printer();
            scanner = new Scanner();
            fax = new Fax();
        }



        public int PrintCounter
        {
            get
            {
                return printer.PrintCounter;
            }
           
        }

        public int ScanCounter
        {
            get
            {
                return scanner.ScanCounter;
            }
            set
            {
                scanner.ScanCounter = value;
            } 
        }

        public int FaxCounter
        {
            get
            {
                return fax.FaxCounter;
            }
        }



        public override void PowerOff()
        {
            if (GetState() == IDevice.State.on)
            {
                state = IDevice.State.off;
                printer.state = IDevice.State.off;
                scanner.state = IDevice.State.off;
                fax.state = IDevice.State.off;
                Console.WriteLine("Devices are shutting down");
            }


        }

        public override void PowerOn()
        {
            if (GetState() == IDevice.State.off)
            {
                state = IDevice.State.on;
                printer.state = IDevice.State.on;
                scanner.state = IDevice.State.on;
                fax.state = IDevice.State.on;
                Console.WriteLine("Devices are turning on");
                Counter++;
            }

        }

        public void Print(in IDocument document)
        {
            printer.Print(document);
        }

        public void Scan(out IDocument document, IDocument.FormatType formatType = IDocument.FormatType.JPG)
        {
            //scanner.Scan(out document, IDocument.FormatType.JPG);
            document =  new TextDocument("");

            if (formatType == IDocument.FormatType.TXT)
            {
                scanner.Scan(out document,IDocument.FormatType.TXT);
            }
            else if (formatType == IDocument.FormatType.JPG)
            {
                scanner.Scan(out document, IDocument.FormatType.JPG);
            }
            else if (formatType == IDocument.FormatType.PDF)
            {
                scanner.Scan(out document, IDocument.FormatType.PDF);
            }
            
        }

        public void ScanPrint()
        {
            if (state == IDevice.State.off)
            {
                return;
            }

            Scan(out document, IDocument.FormatType.JPG);
            Print(document);


        }

        public void Fax_1(IDocument document)
        {
            this.fax.Fax_1(document);
        }
    }
}

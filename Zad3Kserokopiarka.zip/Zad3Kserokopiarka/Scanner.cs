﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace Zad3Kserokopiarka
{
    public class Scanner:BaseDevice,IScanner
    {
        public int ScanCounter;

        public void Scan( out IDocument document, IDocument.FormatType formatType = IDocument.FormatType.JPG)
        {
            string file_name = "";

            document = new TextDocument("");

            if (GetState() == IDevice.State.on)
            {
                ScanCounter++;
                if (formatType == IDocument.FormatType.TXT)
                {
                    file_name = $"TextScan{ScanCounter}.txt";
                    document = new TextDocument($"TextScan{ScanCounter}.txt");
                    formatType = IDocument.FormatType.TXT;
                }
                else if (formatType == IDocument.FormatType.JPG)
                {
                    file_name = $"ImageScan{ScanCounter}.jpg";
                    document = new ImageDocument($"ImageScan{ScanCounter}.jpg");
                    formatType = IDocument.FormatType.JPG;
                }
                else if (formatType == IDocument.FormatType.PDF)
                {
                    file_name = $"PDFScan{ScanCounter}.pdf";
                    document = new PDFDocument($"PDFScan{ScanCounter}.pdf");
                    formatType = IDocument.FormatType.PDF;
                }


            }

            Console.WriteLine($"{DateTime.Now} Scan: {document.GetFileName()}");
        }

      
    }
}

﻿using System;
namespace Zad3Kserokopiarka
{
    class Program1
    {
        private static void Main()
        {
            var device = new Multidimensionaldevice();
            device.PowerOn(); // działa

            IDocument testDoc = new PDFDocument("test");
            device.Print(in testDoc); //działa

            device.Scan(out testDoc);
            device.Scan(out testDoc, formatType: IDocument.FormatType.PDF);//działa

            device.ScanPrint();
            device.Fax_1(testDoc); //działa

            IDocument doc1;
            device.Scan(out doc1, formatType: IDocument.FormatType.PDF); // działa


            Console.WriteLine(device.PrintCounter);
        }
    }
}
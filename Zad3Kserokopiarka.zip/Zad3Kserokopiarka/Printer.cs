﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace Zad3Kserokopiarka
{
    public class Printer:BaseDevice,IPrinter
    {
        public int PrintCounter;

        public void Print( in IDocument document)
        {
            if (GetState() == IDevice.State.on)
            {
                PrintCounter++;
                string file_type = document.GetFileName();
                Console.WriteLine($"{DateTime.Now} , {file_type}");
            }
            
        }

       
    }
}

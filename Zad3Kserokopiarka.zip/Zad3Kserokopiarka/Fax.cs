﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace Zad3Kserokopiarka
{
    public class Fax:BaseDevice,IFAX
    {
        public int FaxCounter;
        public void Fax_1(IDocument document)
        {
            if (state == IDevice.State.on)
            {
                FaxCounter++;
                Console.WriteLine($"{DateTime.Now} fax:{document.GetFileName()}");
            }
        }

    }
}

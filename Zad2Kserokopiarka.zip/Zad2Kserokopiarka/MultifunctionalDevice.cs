﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static ver1.IDevice;
using ver1;

namespace Zad2Kserokopiarka
{
    public class MultifunctionalDevice: BaseDevice
    {
        public int PrintCounter {get;set;}
        public int ScanCounter { get;set;}
        public int FaxCounter { get;set;}

        public void Print(IDocument document)
        {
            if (state == IDevice.State.on)
            {
                PrintCounter++;
                string file_type = document.GetFileName();
                Console.WriteLine($"{DateTime.Now} , {file_type}");
            }


        }

        public void Scan(IDocument document, IDocument.FormatType formatType = IDocument.FormatType.TXT)
        {
            string file_name = "";

            if (state == IDevice.State.on)
            {
                ScanCounter++;
               
                if (formatType == IDocument.FormatType.TXT)
                {
                    file_name = $"TextScan{ScanCounter}.txt";
                    document = new TextDocument(file_name);
                }
                else if (formatType == IDocument.FormatType.JPG)
                {
                    file_name = $"ImageScan{ScanCounter}.jpg";
                    document = new ImageDocument(file_name);
                }
                else if (formatType == IDocument.FormatType.PDF)
                {
                    file_name = $"PDFScan{ScanCounter}.pdf";
                    document = new PDFDocument(file_name);
                }
            }

            Console.WriteLine($"{DateTime.Now} Scan:{file_name}");
        }

        public void ScanAndPrint(IDocument document)
        {
            if (state == IDevice.State.on)
            {
                Scan(document, IDocument.FormatType.JPG);
                Print(document);
            }
        }

        public void Fax(IDocument document)
        {
            if (state == IDevice.State.on)
            {
                FaxCounter++;
                
                Console.WriteLine($"{DateTime.Now} fax:{document}");
            }
        }


    }
}

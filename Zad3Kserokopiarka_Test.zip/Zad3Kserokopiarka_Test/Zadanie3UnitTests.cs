using Microsoft.VisualStudio.TestTools.UnitTesting;
using Zad3Kserokopiarka;
using System;
using System.IO;



namespace Zadanie3UnitTests
{
    public class ConsoleRedirectionToStringWriter : IDisposable
    {
        private StringWriter stringWriter;
        private TextWriter originalOutput;

        public ConsoleRedirectionToStringWriter()
        {
            stringWriter = new StringWriter();
            originalOutput = Console.Out;
            Console.SetOut(stringWriter);
        }

        public string GetOutput()
        {
            return stringWriter.ToString();
        }

        public void Dispose()
        {
            Console.SetOut(originalOutput);
            stringWriter.Dispose();
        }
    }


    [TestClass]
    public class UnitTestmultidimensional
    {
        [TestMethod]
        public void MultidimensionalDevice_GetState_StateOff()
        {
            Multidimensionaldevice multidimensionaldevice  = new Multidimensionaldevice();
            multidimensionaldevice.PowerOff();

            Assert.AreEqual(IDevice.State.off, multidimensionaldevice.GetState());
        }

        [TestMethod]
        public void MultidimesionalDevice_GetState_StateOn()
        {
            Multidimensionaldevice multidimensionaldevice = new Multidimensionaldevice();
            multidimensionaldevice.PowerOn();

            Assert.AreEqual(IDevice.State.on, multidimensionaldevice.GetState());
        }

        [TestMethod]
        public void MultidimesionalDevice_Print_DeviceOn()
        {
            // Arrange
            var printer = new Printer();
            printer.PowerOn();
            int initialPrintCounter = printer.PrintCounter;
            string expectedOutput = $"{DateTime.Now} , FileName.pdf";

            // Redirect Console.Out
            var consoleOutput = new StringWriter();
            Console.SetOut(consoleOutput);

            // Act
            var document = new PDFDocument("FileName.pdf");
            printer.Print(document);

            // Assert
            Assert.AreEqual(initialPrintCounter + 1, printer.PrintCounter);
            Assert.AreEqual(expectedOutput, consoleOutput.ToString().Trim());
        }

        
        [TestMethod]
        public void MultidimesionalDevice_Scan_DeviceOn()
        {
            // Arrange
            var multidimensional = new Multidimensionaldevice();
            multidimensional.PowerOn();

            var currentConsoleOut = Console.Out;
            currentConsoleOut.Flush();

            // Redirect Console.Out
            using (var consoleOutput = new ConsoleRedirectionToStringWriter())
            {
                // Act
                IDocument doc1 = new TextDocument("kkk.text");
                multidimensional.Scan(out doc1);

                // Assert
                Assert.IsTrue(consoleOutput.GetOutput().Contains("Scan"));
            }

            // Assert
            Assert.AreEqual(currentConsoleOut, Console.Out);
        }

        [TestMethod]
        public void MultidimesionalDevice_Scan_FormatTypeDocument()
        {
            var multidimensional = new Multidimensionaldevice();
            multidimensional.PowerOn();

            var currentConsoleOut = Console.Out;
            currentConsoleOut.Flush();
            using (var consoleOutput = new ConsoleRedirectionToStringWriter())
            {
                IDocument doc1 = new TextDocument("jjj.text");
                multidimensional.Scan(out doc1, formatType: IDocument.FormatType.JPG);
             
                Assert.IsTrue(consoleOutput.GetOutput().Contains(".jpg"));

                multidimensional.Scan(out doc1, formatType: IDocument.FormatType.TXT);
           
                Assert.IsTrue(consoleOutput.GetOutput().Contains(".txt"));

                multidimensional.Scan(out doc1, formatType: IDocument.FormatType.PDF);
      
                Assert.IsTrue(consoleOutput.GetOutput().Contains(".pdf"));
            }
            Assert.AreEqual(currentConsoleOut, Console.Out);
        }

        [TestMethod]
        public void MultidimesionalDevice_ScanAndPrint_DeviceOn()
        {
            // Arrange
            var multidimensional = new Multidimensionaldevice();
            multidimensional.PowerOn();

            IDocument docFax = new PDFDocument("faaax.pdf");

            var currentConsoleOut = Console.Out;
            currentConsoleOut.Flush();

            // Redirect Console.Out
            using (var consoleOutput = new ConsoleRedirectionToStringWriter())
            {
                // Act
                multidimensional.Fax_1(docFax);
            }

            // Assert
            Assert.AreEqual(currentConsoleOut, Console.Out);
        }

      

        [TestMethod]
        public void MultidimensionalDevice_PrintCounter()
        {
            var multidimensional = new Multidimensionaldevice();
            multidimensional.PowerOn();

            IDocument doc1 = new PDFDocument("aaa.pdf");
            multidimensional.Print(doc1);
            IDocument doc2 = new TextDocument("aaa.txt");
            multidimensional.Print(doc2);
            IDocument doc3 = new ImageDocument("aaa.jpg");
            multidimensional.Print(doc3);

            Assert.AreEqual(3,multidimensional.PrintCounter);
        }

        [TestMethod]
        public void MultidimensionalDevice_ScanCounter()
        {
            var multidimensional = new Multidimensionaldevice();
            multidimensional.PowerOn();

            IDocument doc1 = new TextDocument("kkk.text");
            multidimensional.Scan(out doc1);
            IDocument doc2 = new TextDocument("kkk.text"); 
            multidimensional.Scan(out doc2);

            Assert.AreEqual(2, multidimensional.ScanCounter);
        }

        [TestMethod]
        public void MultidimensionalDevice_SendCounter()
        {
            var multidimensional = new Multidimensionaldevice();
            multidimensional.PowerOn();

            IDocument docFax1 = new PDFDocument("fax.pdf");
            IDocument docFax2 = new PDFDocument("fax.pdf");

            multidimensional.Fax_1(docFax1);

            multidimensional.PowerOff();
            multidimensional.Fax_1(docFax2);
            multidimensional.PowerOn();

            multidimensional.Fax_1(docFax2);

            Assert.AreEqual(2, multidimensional.FaxCounter);
        }

        [TestMethod]
        public void MultidimesionalDevice_PowerOnCounter()
        {
            Multidimensionaldevice multidimensionaldevice = new Multidimensionaldevice();
            multidimensionaldevice.PowerOn();
            multidimensionaldevice.PowerOff();
            multidimensionaldevice.PowerOn();
            multidimensionaldevice.PowerOff();
            multidimensionaldevice.PowerOn();

            Assert.AreEqual(3, multidimensionaldevice.Counter);
        }

    }
}
